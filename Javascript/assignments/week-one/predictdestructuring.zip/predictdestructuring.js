//.......................//
//PROBLEM 1 - PREDICTION = ERROR because const is immutable and we already defined 'cars' on line 3
const cars = ['Tesla', 'Mercedes', 'Honda']
const [ randomCar ] = cars
const [ ,otherRandomCar ] = cars
//Predict the output
console.log(randomCar)
console.log(otherRandomCar)

//......................//
//PROBLEM 2 - PREDICTION =Error because const is immutable
const employee = {
    name: 'Elon',
    age: 47,
    company: 'Tesla'
}
const { name: otherName } = employee;
//Predict the output
console.log(name);
console.log(otherName);

//.........................//
//PROBLEM 3 
const person = {
    name: 'Phil Smith',
    age: 47,
    height: '6 feet'
}
const password = '12345';
const { password: hashedPassword } = person;  
//Predict the output
console.log(password); //PREDICTION- 12345
console.log(hashedPassword); //PREDICTION - error because password is not a key within the object

//.........................//
//PROBLEM 4 
const numbers = [8, 2, 3, 5, 6, 1, 67, 12, 2];
const [,first] = numbers;
const [,,,second] = numbers;
const [,,,,,,,,third] = numbers;
//Predict the output
console.log(first == second);//PREDICTION = 5
console.log(first == third);//PREDICTION =2

//.......................//
//PROBLEM 5
const lastTest = {
    key: 'value',
    secondKey: [1, 5, 1, 8, 3, 3]
}
const { key } = lastTest;
const { secondKey } = lastTest;
const [ ,willThisWork] = secondKey;
//Predict the output
console.log(key);//PREDICTION -'value'
console.log(secondKey);//PREDICTION -[1,5,1,8,3,3]
console.log(secondKey[0]);//PREDICTION - 1
console.log(willThisWork); //PREDICTION-error because secondKey is not an object
